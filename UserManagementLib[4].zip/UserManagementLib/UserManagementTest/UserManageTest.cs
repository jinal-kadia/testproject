﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using UserManagementLib;
using UserManagementLib.Model;
using UserManagementLib.Repo;

namespace UserManagementTest
{
    [TestClass]
    public class UserManageTest
    {
        public readonly UserDbContext UserDbContextMock;
        /// <summary>
        /// Initialise test setup with data and mock methods
        /// </summary>
        public UserManageTest()
        {
            
            
            // Create a mock implementation of the DbContext 
            
            Mock<UserDbContext> mockContext = new Mock<UserDbContext>();
            mockContext.Setup(c => c.Users).Returns(new MockDbSet<User>());
            
            mockContext.Object.Users.Add(
                new User
                {
                    FirstName = "Jim",
                    LastName = "Jam",
                    Address = "abc",
                    EmailAddress = "jim.jam@gmail.com",
                    Password = "Abc@12345",
                    MobilePhoneNumber = "123232424"
                }
            );

            UserDbContextMock = mockContext.Object;
        }

        /// <summary>
        /// Test add user
        /// </summary>
        [TestMethod]
        public void CanAddUser()
        {
            User addUser = new User
            {
                FirstName = "Test",
                LastName = "User",
                EmailAddress = "test.user@gmail.com",
                Password = "Xyz@12345",
                Address = "abc",
                MobilePhoneNumber = "1223243434"
            };

            IUserRepo userRepo = new UserRepo(UserDbContextMock);

            var check = userRepo.AddUser(addUser);

            //Returned true
            Assert.AreEqual(true, check);

            //Verify added user by get
            User user = userRepo.GetUser("test.user@gmail.com");

            Assert.IsNotNull(user);
        }
        /// <summary>
        /// Test get user by email address
        /// </summary>
        [TestMethod]
        public void CanGetValidUser()
        {
            IUserRepo userRepo = new UserRepo(UserDbContextMock);
            User user = userRepo.GetUser("jim.jam@gmail.com");
            
            //Validate if found valid user
            Assert.IsNotNull(user);

            //Validate returned user name
            Assert.AreEqual(user.FirstName,"Jim");
        }

        /// <summary>
        /// Test get user with invalid email address
        /// </summary>
        [TestMethod]
        public void CannotGetInValidUser()
        {
            IUserRepo userRepo = new UserRepo(UserDbContextMock);

            User user = userRepo.GetUser("jim@gmail.com");

            //Validate user not found
            Assert.IsNull(user);

        }

        /// <summary>
        /// Test validate login
        /// </summary>
        [TestMethod]
        public void ValidatedLogin()
        {
            IUserRepo userRepo = new UserRepo(UserDbContextMock);

            bool check = userRepo.ValidateLogin("jim.jam@gmail.com", "Abc@12345");

            //Validate user login
            Assert.AreEqual(true,check);

        }
    }
}
