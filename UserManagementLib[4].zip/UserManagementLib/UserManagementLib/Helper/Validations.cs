﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace UserManagementLib.Helper
{
    /// <summary>
    /// Helper functions for validation
    /// </summary>
    public static class Validations
    {
        //Regex string to use for validation
        static Regex PhoneNumberRegEx = new Regex(@"^[0-9 ()+]{0,32}$");
        static Regex EmailRegEx = new Regex(@"^(?=.{0,256}$)[a-zA-Z0-9!#$%&+^_`{}~-]+(?:\.[a-zA-Z0-9!#$%&+^_`{}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$");
        static Regex PasswordRegex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$");

        /// <summary>
        /// Validate email address
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <returns>true - if emailaddress is valid, false - otherwise</returns>
        public static bool ValidateEmail(string emailAddress)
        {
            return !string.IsNullOrWhiteSpace(emailAddress) && EmailRegEx.IsMatch(emailAddress);
        }

        /// <summary>
        /// Validate phone number
        /// </summary>
        /// <param name="mobileNumber"></param>
        /// <returns>True - when number is valid, false - otherwise</returns>
        public static bool ValidateMobileNumer(string mobileNumber)
        {
            return !string.IsNullOrWhiteSpace(mobileNumber) && PhoneNumberRegEx.IsMatch(mobileNumber);
        }

        /// <summary>
        /// Validate password. Must be 8 characters with mix of lower, upper and special character
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool ValidatePassword(string password)
        {
            return !string.IsNullOrWhiteSpace(password);
            //&& PasswordRegex.IsMatch(password);
        }

    }
}
