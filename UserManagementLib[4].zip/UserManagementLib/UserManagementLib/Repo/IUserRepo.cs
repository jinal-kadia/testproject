﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagementLib.Model;

namespace UserManagementLib.Repo
{
    /// <summary>
    /// User repository to manage users
    /// </summary>
    public interface IUserRepo
    {
        /// <summary>
        /// Add user
        /// </summary>
        /// <param name="user"></param>
        /// <returns>false - when add failed, true - when added successfully</returns>
        bool AddUser(User user);

        /// <summary>
        /// Get user based on email address
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        User GetUser(string emailAddress);

        /// <summary>
        /// Validate user credentials,
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <param name="password"></param>
        /// <returns>true - if user is valid</returns>
        bool ValidateLogin(string emailAddress, string password);
    }
}
