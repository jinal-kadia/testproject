﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagementLib.Helper;
using UserManagementLib.Model;

namespace UserManagementLib.Repo
{
    ///<InheritDoc/>
    public class UserRepo:IUserRepo
    {
        private readonly UserDbContext _dbContext;
        public UserRepo(UserDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public bool AddUser(User user)
        {   
            try
            {
                if (!IsValidUser(user)) return false;

                _dbContext.Users.Add(user);
                _dbContext.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                //TODO:Add logger
            }
            return false;
        }

        public User GetUser(string emailAddress)
        {
            if (string.IsNullOrWhiteSpace(emailAddress)) return null;
            try
            {
                return _dbContext.Users.FirstOrDefault(u => u.EmailAddress == emailAddress);
            }
            catch (Exception ex)
            {
                //TODO:Add logger
            }
            return null;
        }

        public bool ValidateLogin(string emailAddress, string password)
        {
            if (!Validations.ValidateEmail(emailAddress) || string.IsNullOrWhiteSpace(password)) return false;

            var user = GetUser(emailAddress);

            if (user != null && user.Password.Equals(password)) return true;

            return false;
            ;
        }

        /// <summary>
        /// Validate user details
        /// </summary>
        /// <param name="user"></param>
        /// <returns>True - When user details are correct, False - Otherwise</returns>
        private bool IsValidUser(User user)
        {
            //TODO:Add validation regex for name fields
            return user != null
                   && Validations.ValidateEmail(user.EmailAddress)
                   && Validations.ValidateMobileNumer(user.MobilePhoneNumber)
                   && Validations.ValidatePassword(user.Password)
                   && !string.IsNullOrWhiteSpace(user.FirstName)
                   && !string.IsNullOrWhiteSpace(user.LastName)
                   && !string.IsNullOrWhiteSpace(user.Address);
        }
    }
}
