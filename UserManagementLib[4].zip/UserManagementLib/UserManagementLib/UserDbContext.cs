﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;
using System.Linq;
using UserManagementLib.Model;

namespace UserManagementLib
{
    public class UserDbContext:DbContext
    {
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //TODO:Add implementation for DB entity Creation
        }
        public virtual DbSet<User> Users { get; set; }
    }
}
